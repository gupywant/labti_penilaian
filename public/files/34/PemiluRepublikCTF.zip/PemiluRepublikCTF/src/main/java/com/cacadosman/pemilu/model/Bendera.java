package com.cacadosman.pemilu.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "REDACTED")
public class Bendera {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "REDACTED")
    private Redacted redacted1;

    @Column(name = "REDACTED")
    private Redacted redacted2;
}
