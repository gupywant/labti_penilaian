package com.cacadosman.pemilu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PemiluApplication {

    public static void main(String[] args) {
        SpringApplication.run(PemiluApplication.class, args);
    }

}
